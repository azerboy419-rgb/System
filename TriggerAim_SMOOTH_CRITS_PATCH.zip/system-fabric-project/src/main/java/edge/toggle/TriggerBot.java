package edge.toggle;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.Hand;

/** Smart attack timing against the exact target selected by Targeting. */
final class TriggerBot {
    void tick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.interactionManager == null || client.currentScreen != null) return;
        if (Config.WEAPON_ONLY && !Config.holdingWeapon(player)) return;

        LivingEntity target = Targeting.current();
        if (!Targeting.isAttackable(client, target)) return;
        if (player.getAttackCooldownProgress(0.5f) < 1.0f) return;

        boolean criticalWindow = isCriticalHitWindow(player);

        // Grounded attacks maintain a combo. While airborne, wait for the falling
        // critical window instead of wasting the hit on jump ascent or knock-up.
        if (!player.isOnGround() && !criticalWindow) return;
        if (Config.CRITICAL_HITS_ONLY && !criticalWindow) return;

        client.interactionManager.attackEntity(player, target);
        player.swingHand(Hand.MAIN_HAND);
    }

    private static boolean isCriticalHitWindow(ClientPlayerEntity player) {
        return !player.isOnGround()
                && player.getVelocity().y < -0.08
                && player.fallDistance > 0.0f
                && !player.isClimbing()
                && !player.isTouchingWater()
                && !player.isInLava()
                && !player.hasVehicle()
                && !player.isSprinting()
                && !player.hasStatusEffect(StatusEffects.BLINDNESS);
    }
}
