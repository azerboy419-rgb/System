# Trigger Aim — Fabric 1.21.11

Client-side project combining smooth target tracking and cooldown-aware attacks.

## Defaults
- Toggle: **R**
- Players only; weapon condition enabled
- Aim distance: 4.5 blocks; FOV: 180 degrees
- Strength: 75%; speed: 5; health priority; sticky target
- Attack reach: 3 blocks; full attack cooldown required
- Smart attack mode: when a critical window is available it may produce a critical hit; otherwise normal cooldown hits remain enabled for combos. Set `CRITICAL_HITS_ONLY = true` in `Config.java` to wait for a critical window only.

## Architecture
`Targeting` owns the shared target. `AimAssist` uses damped rotation with per-tick limits. `TriggerBot` attacks only that same locked target, subject to reach, visibility, weapon and cooldown checks. The target is not reselected simply because another player has lower health; it is replaced when no longer valid.

## Build
Use a compatible JDK (Java 21+; the selected Loom/Gradle combination may require a newer JDK) and run `./gradlew build` or `gradlew.bat build`. The JAR should appear under `build/libs/`.

## Verification status
Source changes and ZIP structure are prepared. This environment could not download the Gradle distribution, so compilation and live Minecraft behavior have **not** been verified. Critical-hit detection is an approximation; server-side combat rules and latency can affect actual critical registration.
