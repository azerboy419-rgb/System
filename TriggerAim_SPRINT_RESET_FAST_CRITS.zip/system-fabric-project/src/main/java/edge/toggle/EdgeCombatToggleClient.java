package edge.toggle;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class EdgeCombatToggleClient implements ClientModInitializer {
    private static KeyBinding toggleKey;
    private static final TriggerBot TRIGGER_BOT = new TriggerBot();
    private static final AimAssist AIM_ASSIST = new AimAssist();
    private static boolean enabled;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.edge_combat_toggle.toggle", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_R, KeyBinding.Category.MISC));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
                if (client.player != null) client.player.sendMessage(
                        Text.literal("Trigger Aim: " + (enabled ? "ON" : "OFF")), true);
                if (!enabled) resetState();
            }

            if (!enabled || client.player == null || client.world == null) {
                if (client.player == null || client.world == null) resetState();
                return;
            }

            // Resolve one target first, rotate toward it second, attack that same target last.
            Targeting.update(client);
            AIM_ASSIST.tick(client);
            TRIGGER_BOT.tick(client);
        });
    }

    private static void resetState() {
        Targeting.reset();
        AIM_ASSIST.reset();
    }
}
