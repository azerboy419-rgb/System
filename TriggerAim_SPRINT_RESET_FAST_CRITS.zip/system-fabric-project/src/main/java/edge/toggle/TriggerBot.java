package edge.toggle;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.Hand;

/**
 * Cooldown-aware attack timing. Sprint is briefly stopped before a critical
 * attempt because vanilla critical hits require the player not to be sprinting.
 */
final class TriggerBot {
    private boolean wasAirborne;
    private boolean sprintResetPending;

    void tick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.interactionManager == null || client.currentScreen != null) {
            wasAirborne = false;
            sprintResetPending = false;
            return;
        }
        if (Config.WEAPON_ONLY && !Config.holdingWeapon(player)) {
            restoreSprintIfNeeded(player);
            return;
        }

        LivingEntity target = Targeting.current();
        if (!Targeting.isAttackable(client, target)) {
            restoreSprintIfNeeded(player);
            return;
        }

        // Attack immediately on the first tick where vanilla's attack meter is full.
        if (player.getAttackCooldownProgress(0.0f) < 1.0f) {
            wasAirborne = !player.isOnGround();
            return;
        }

        boolean jumpCritMode = client.options.jumpKey.isPressed()
                || (!player.isOnGround() && wasAirborne);
        boolean criticalWindow = isCriticalHitWindow(player);

        if (jumpCritMode) {
            // Do not spend a charged hit on the ground, on ascent, or early in a jump.
            if (!criticalWindow) {
                wasAirborne = !player.isOnGround();
                restoreSprintIfNeeded(player);
                return;
            }

            // Sprinting prevents vanilla criticals. Stop sprint for one tick, then
            // attempt the hit on the next eligible falling tick.
            if (player.isSprinting() && !sprintResetPending) {
                player.setSprinting(false);
                sprintResetPending = true;
                wasAirborne = true;
                return;
            }
        } else {
            // Ground combo mode: avoid spending a hit in the air unintentionally.
            if (!player.isOnGround()) {
                wasAirborne = true;
                restoreSprintIfNeeded(player);
                return;
            }
        }

        if (Config.CRITICAL_HITS_ONLY && !criticalWindow) {
            restoreSprintIfNeeded(player);
            return;
        }

        client.interactionManager.attackEntity(player, target);
        player.swingHand(Hand.MAIN_HAND);
        wasAirborne = !player.isOnGround();
        restoreSprintIfNeeded(player);
    }

    private void restoreSprintIfNeeded(ClientPlayerEntity player) {
        if (sprintResetPending) {
            sprintResetPending = false;
            // Restore only when the player is still holding forward; vanilla may
            // still reject sprinting if hunger, collision, or movement state disallows it.
            if (player.input != null && player.input.hasForwardMovement()) {
                player.setSprinting(true);
            }
        }
    }

    private static boolean isCriticalHitWindow(ClientPlayerEntity player) {
        return !player.isOnGround()
                && player.getVelocity().y < -0.08
                && player.fallDistance > 0.0f
                && !player.isClimbing()
                && !player.isTouchingWater()
                && !player.isInLava()
                && !player.hasVehicle()
                && !player.isSprinting()
                && !player.hasStatusEffect(StatusEffects.BLINDNESS);
    }
}
