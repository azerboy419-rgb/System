package edge.toggle;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Smooth, non-oscillating camera tracking for the shared locked target. */
final class AimAssist {
    void tick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        LivingEntity target = Targeting.current();
        if (player == null || target == null || !target.isAlive()) return;

        Vec3d eye = player.getEyePos();
        Vec3d point = Targeting.aimPoint(target);
        float yawError = MathHelper.wrapDegrees(Targeting.yawTo(eye, point) - player.getYaw());
        float pitchError = MathHelper.wrapDegrees(Targeting.pitchTo(eye, point) - player.getPitch());

        // Ignore tiny errors to prevent camera micro-jitter.
        if (Math.abs(yawError) < 0.12f) yawError = 0.0f;
        if (Math.abs(pitchError) < 0.12f) pitchError = 0.0f;

        // Direct exponential smoothing avoids the spring overshoot that caused shaking.
        float smoothing = (float) MathHelper.clamp(Config.SPEED / 28.0, 0.12, 0.28);
        float strength = (float) (Config.STRENGTH / 100.0);
        float yawStep = MathHelper.clamp(yawError * smoothing * strength,
                -Config.MAX_TURN_PER_TICK, Config.MAX_TURN_PER_TICK);
        float pitchStep = MathHelper.clamp(pitchError * smoothing * strength,
                -Config.MAX_TURN_PER_TICK, Config.MAX_TURN_PER_TICK);

        player.setYaw(player.getYaw() + yawStep);
        player.setPitch(MathHelper.clamp(player.getPitch() + pitchStep, -90.0f, 90.0f));
    }

    void reset() {}
}
