package edge.toggle;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Shared target state used by Aim Assist and TriggerBot. */
final class Targeting {
    private static LivingEntity current;
    private static long lastSeenTick;

    private Targeting() {}

    static LivingEntity current() { return current; }

    static void update(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.world == null || !player.isAlive()
                || (Config.AIM_WEAPON_ONLY && !Config.holdingWeapon(player))) {
            reset();
            return;
        }

        long tick = player.age;
        Vec3d eye = player.getEyePos();
        // Keep the locked target regardless of health changes or nearby alternatives.
        if (isRetainable(current, player, eye)) {
            lastSeenTick = tick;
            return;
        }
        current = null;

        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;
        for (Entity entity : client.world.getEntities()) {
            if (!(entity instanceof LivingEntity living) || living == player) continue;
            if (!isCandidate(living, player, eye)) continue;
            Vec3d point = aimPoint(living);
            double distance = eye.distanceTo(point);
            double yaw = Math.abs(MathHelper.wrapDegrees(yawTo(eye, point) - player.getYaw()));
            double pitch = Math.abs(MathHelper.wrapDegrees(pitchTo(eye, point) - player.getPitch()));
            double angle = Math.hypot(yaw, pitch);
            // Choose the player the crosshair is already closest to. Health is only
            // a tie-breaker, so a low-health player off to the side won't steal aim.
            double score = angle * 4.0 + distance * 0.12 + living.getHealth() * 0.015;
            if (score < bestScore) { bestScore = score; best = living; }
        }
        current = best;
        if (best != null) lastSeenTick = tick;
    }

    static boolean isAttackable(MinecraftClient client, LivingEntity target) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.world == null || target == null || target != current) return false;
        if (!isRetainable(target, player, player.getEyePos())) return false;
        Vec3d eye = player.getEyePos();
        Vec3d point = aimPoint(target);
        if (eye.distanceTo(point) > Config.REACH) return false;
        return player.canSee(target);
    }

    private static boolean isCandidate(LivingEntity target, ClientPlayerEntity player, Vec3d eye) {
        if (!isRetainable(target, player, eye)) return false;
        Vec3d point = aimPoint(target);
        double yaw = Math.abs(MathHelper.wrapDegrees(yawTo(eye, point) - player.getYaw()));
        return yaw <= Config.FOV / 2.0;
    }

    private static boolean isRetainable(LivingEntity target, ClientPlayerEntity player, Vec3d eye) {
        if (target == null || target == player || !target.isAlive() || !Config.matches(target)) return false;
        if (eye.distanceTo(aimPoint(target)) > Config.DISTANCE) return false;
        return player.canSee(target);
    }

    static Vec3d aimPoint(LivingEntity target) {
        // Aim slightly above the box centre for a steadier, more natural track.
        return target.getBoundingBox().getCenter().add(0.0, target.getHeight() * 0.08, 0.0);
    }

    static float yawTo(Vec3d from, Vec3d to) {
        return (float) (Math.toDegrees(Math.atan2(to.z - from.z, to.x - from.x)) - 90.0);
    }

    static float pitchTo(Vec3d from, Vec3d to) {
        double dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
        return (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
    }

    static void reset() { current = null; lastSeenTick = 0L; }
}
