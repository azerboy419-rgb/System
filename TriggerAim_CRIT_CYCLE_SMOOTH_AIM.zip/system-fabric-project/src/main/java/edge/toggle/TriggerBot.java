package edge.toggle;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.Hand;

/** Smart attack timing: grounded combos or deliberate jump-crit cycles. */
final class TriggerBot {
    private boolean wasAirborne;

    void tick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.interactionManager == null || client.currentScreen != null) {
            wasAirborne = false;
            return;
        }
        if (Config.WEAPON_ONLY && !Config.holdingWeapon(player)) return;

        LivingEntity target = Targeting.current();
        if (!Targeting.isAttackable(client, target)) return;

        // Require a completely charged attack bar. Do not use partial-strength hits
        // just because the player lands between repeated jump-critical attempts.
        if (player.getAttackCooldownProgress(0.0f) < 1.0f) return;

        boolean jumpCritMode = client.options.jumpKey.isPressed()
                || (!player.isOnGround() && wasAirborne);
        boolean criticalWindow = isCriticalHitWindow(player);

        if (jumpCritMode) {
            // While the jump key is held, never spend the charged hit on the ground,
            // on ascent, or during the early fall. Wait for a real falling crit window.
            if (!criticalWindow) {
                wasAirborne = !player.isOnGround();
                return;
            }
        } else {
            // Ordinary combo mode: only attack from the ground, avoiding accidental
            // non-critical attacks while airborne.
            if (!player.isOnGround()) {
                wasAirborne = true;
                return;
            }
        }

        if (Config.CRITICAL_HITS_ONLY && !criticalWindow) return;

        client.interactionManager.attackEntity(player, target);
        player.swingHand(Hand.MAIN_HAND);
        wasAirborne = !player.isOnGround();
    }

    private static boolean isCriticalHitWindow(ClientPlayerEntity player) {
        return !player.isOnGround()
                && player.getVelocity().y < -0.08
                && player.fallDistance > 0.0f
                && !player.isClimbing()
                && !player.isTouchingWater()
                && !player.isInLava()
                && !player.hasVehicle()
                && !player.isSprinting()
                && !player.hasStatusEffect(StatusEffects.BLINDNESS);
    }
}
