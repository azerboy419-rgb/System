package edge.toggle;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;

final class Config {
    private Config() {}

    static final double REACH = 3.0;
    static final boolean WEAPON_ONLY = true;
    // Smart mode: false allows normal cooldown hits/combo when a critical is not available.
    static final boolean CRITICAL_HITS_ONLY = false;

    static final double DISTANCE = 4.5;
    static final double FOV = 180.0;
    static final double STRENGTH = 75.0;
    static final double SPEED = 5.0;
    static final float MAX_TURN_PER_TICK = 12.0f;
    static final boolean STICKY = true;
    static final String PRIORITY = "Health";
    static final boolean AIM_WEAPON_ONLY = true;

    static boolean matches(LivingEntity entity) {
        return entity instanceof PlayerEntity && entity.isAlive();
    }

    static boolean holdingWeapon(ClientPlayerEntity player) {
        ItemStack stack = player.getMainHandStack();
        return stack.isIn(ItemTags.SWORDS) || stack.isIn(ItemTags.AXES)
                || stack.isOf(Items.MACE) || stack.isOf(Items.TRIDENT);
    }
}
