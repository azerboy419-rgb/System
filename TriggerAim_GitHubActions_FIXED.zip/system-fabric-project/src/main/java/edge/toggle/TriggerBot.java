package edge.toggle;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.Hand;

/** Smart attack timing against the exact target selected by Targeting. */
final class TriggerBot {
    void tick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.interactionManager == null || client.currentScreen != null) return;
        if (Config.WEAPON_ONLY && !Config.holdingWeapon(player)) return;

        LivingEntity target = Targeting.current();
        if (!Targeting.isAttackable(client, target)) return;
        if (player.getAttackCooldownProgress(0.5f) < 1.0f) return;

        boolean criticalWindow = isCriticalHitWindow(player);
        // If critical-only is enabled, wait for a real candidate window; otherwise attack
        // on cooldown so grounded hits can continue a combo instead of stalling in mid-fight.
        if (Config.CRITICAL_HITS_ONLY && !criticalWindow) return;

        client.interactionManager.attackEntity(player, target);
        player.swingHand(Hand.MAIN_HAND);
    }

    private static boolean isCriticalHitWindow(ClientPlayerEntity player) {
        return !player.isOnGround()
                && player.getVelocity().y < -0.08
                && player.fallDistance > 0.0f
                && !player.isClimbing()
                && !player.isTouchingWater()
                && !player.isInLava()
                && !player.hasVehicle()
                && !player.isSprinting()
                && !player.hasStatusEffect(StatusEffects.BLINDNESS);
    }
}
