package edge.toggle;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Smooth, damped camera tracking for the shared locked target. */
final class AimAssist {
    private float yawVelocity;
    private float pitchVelocity;

    void tick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        LivingEntity target = Targeting.current();
        if (player == null || target == null || !target.isAlive()) { reset(); return; }

        Vec3d eye = player.getEyePos();
        Vec3d point = Targeting.aimPoint(target);
        float yawError = MathHelper.wrapDegrees(Targeting.yawTo(eye, point) - player.getYaw());
        float pitchError = MathHelper.wrapDegrees(Targeting.pitchTo(eye, point) - player.getPitch());

        // A damped spring avoids repeated overshoot and camera jitter. Cap per-tick movement.
        float responsiveness = (float) MathHelper.clamp(Config.SPEED / 20.0, 0.08, 0.35);
        yawVelocity = (yawVelocity + yawError * responsiveness) * 0.62f;
        pitchVelocity = (pitchVelocity + pitchError * responsiveness) * 0.62f;
        yawVelocity = MathHelper.clamp(yawVelocity, -Config.MAX_TURN_PER_TICK, Config.MAX_TURN_PER_TICK);
        pitchVelocity = MathHelper.clamp(pitchVelocity, -Config.MAX_TURN_PER_TICK, Config.MAX_TURN_PER_TICK);

        float strength = (float) (Config.STRENGTH / 100.0);
        player.setYaw(player.getYaw() + yawVelocity * strength);
        player.setPitch(MathHelper.clamp(player.getPitch() + pitchVelocity * strength, -90.0f, 90.0f));
    }

    void reset() { yawVelocity = 0.0f; pitchVelocity = 0.0f; }
}
