package edge.toggle;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

final class Config {
    private Config() {}

    // Requested Trigger Bot settings
    static final double REACH = 3.0;
    static final boolean WEAPON_ONLY = false;

    // Requested Aim Assist settings
    static final double DISTANCE = 6.0;
    static final double FOV = 360.0;
    static final double STRENGTH = 15.0;
    static final double SPEED = 1.0;
    static final boolean STICKY = false;
    static final String PRIORITY = "Health";

    // Both supplied classes call this shared filter. Keep it player-only so
    // Trigger Bot targets players as requested. The supplied AimAssist.java
    // has no separate armor predicate, so armor-only targeting cannot be
    // enabled independently without changing that source file.
    static boolean matches(LivingEntity entity) {
        return entity instanceof PlayerEntity && entity.isAlive();
    }
}
