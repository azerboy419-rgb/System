# Edge Combat Toggle

Fabric client mod project for Minecraft Java Edition **1.21.11**. The project is configured to build on GitHub Actions with Java 21 and Gradle 9.2.1.

## Build it on GitHub

1. Create a new GitHub repository.
2. Upload the **contents of this project folder** to the repository root (the `.github` folder must be included).
3. Open the repository's **Actions** tab. The `Build Fabric Mod` workflow starts automatically after a push. You can also run it manually with **Run workflow**.
4. Open the successful workflow run and download the artifact named `edge-combat-toggle-minecraft-1.21.11`.
5. Inside the downloaded artifact, use the main mod JAR in Minecraft's `mods` folder. Do not use the `-sources.jar` file.

The workflow runs `gradle --no-daemon clean build` and fails visibly if compilation fails or no JAR is produced. This environment cannot run Gradle locally, so the GitHub Actions result is the actual build verification.

## Included settings

- `R` toggles both features together; they start disabled.
- Trigger Bot: targets players, 3-block reach, checks the attack cooldown before attacking.
- Aim Assist: 360° horizontal field of view, Health priority, 6-block target distance, smooth rotation.
- Minecraft 1.21.11, Fabric Loader, Fabric API, Java 21.

## Source-file constraint

`TriggerBot.java` and `AimAssist.java` are copied byte-for-byte from the supplied files and are not edited. Both use the shared `Config.matches(...)` filter, so the current configuration targets living players for both features. An armor-only Aim Assist filter cannot be added independently while those source files remain unchanged.

## Local build (optional)

Install JDK 21 and Gradle 9.2.1, then run from the project root:

```bash
gradle --no-daemon clean build
```

The mod JAR will be in `build/libs/`.
