package edge.toggle;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class EdgeCombatToggleClient implements ClientModInitializer {
    private static KeyBinding toggleKey;
    private static final TriggerBot TRIGGER_BOT = new TriggerBot();
    private static final AimAssist AIM_ASSIST = new AimAssist();

    private static boolean enabled = false;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.edge_combat_toggle.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_R,
                KeyBinding.Category.MISC
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
                if (client.player != null) {
                    client.player.sendMessage(
                            net.minecraft.text.Text.literal("Edge Combat Toggle: " + (enabled ? "ON" : "OFF")),
                            true
                    );
                }
            }

            if (!enabled || client.player == null || client.world == null) return;

            TRIGGER_BOT.tick(client);
            AIM_ASSIST.tick(client);
        });
    }
}
