package edge.toggle;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;

/**
 * Smart critical TriggerBot adaptation for Fabric.
 * Waits for a descending critical-hit window instead of attacking immediately.
 * This is not the original native System Client implementation.
 */
final class TriggerBot {
    void tick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.interactionManager == null || client.currentScreen != null) return;
        if (Config.WEAPON_ONLY && !Config.holdingWeapon(player)) return;
        if (!(client.crosshairTarget instanceof EntityHitResult hit)) return;

        Entity target = hit.getEntity();
        if (!(target instanceof LivingEntity living) || !living.isAlive() || !Config.matches(living)) return;
        if (player.getEyePos().distanceTo(hit.getPos()) > Config.REACH) return;

        // Smart mode: do not swing early. Wait until the attack cooldown is ready
        // and the player is actually falling in a valid critical-hit state.
        if (player.getAttackCooldownProgress(0.5f) < 1.0f) return;
        if (!isCriticalHitWindow(player)) return;

        client.interactionManager.attackEntity(player, target);
        player.swingHand(Hand.MAIN_HAND);
    }

    private static boolean isCriticalHitWindow(ClientPlayerEntity player) {
        return !player.isOnGround()
                && player.getVelocity().y < 0.0
                && player.fallDistance > 0.0f
                && !player.isClimbing()
                && !player.isTouchingWater()
                && !player.isInLava()
                && !player.hasVehicle()
                && !player.isSprinting()
                && !player.hasStatusEffect(StatusEffects.BLINDNESS);
    }
}
