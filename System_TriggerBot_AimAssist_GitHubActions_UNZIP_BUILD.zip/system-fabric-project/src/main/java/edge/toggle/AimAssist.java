package edge.toggle;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Fabric-native adaptation of selected Aim Assist settings. */
final class AimAssist {
    private LivingEntity stickyTarget;

    void tick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.world == null || !player.isAlive()) {
            stickyTarget = null;
            return;
        }
        if (Config.AIM_WEAPON_ONLY && !Config.holdingWeapon(player)) {
            stickyTarget = null;
            return;
        }

        Vec3d eye = player.getEyePos();
        LivingEntity target = valid(stickyTarget, player, eye) ? stickyTarget : null;
        if (target == null) {
            stickyTarget = null;
            double bestScore = Double.MAX_VALUE;
            for (Entity entity : client.world.getEntities()) {
                if (!(entity instanceof LivingEntity living) || living == player) continue;
                if (!valid(living, player, eye)) continue;

                Vec3d point = living.getBoundingBox().getCenter();
                double distance = eye.distanceTo(point);
                double angle = Math.abs(MathHelper.wrapDegrees(yawTo(eye, point) - player.getYaw()));
                double score = switch (Config.PRIORITY) {
                    case "Health" -> living.getHealth();
                    case "Angle" -> angle;
                    default -> distance;
                };
                if (score < bestScore) {
                    bestScore = score;
                    target = living;
                }
            }
            stickyTarget = target;
        }
        if (target == null) return;

        Vec3d point = target.getBoundingBox().getCenter();
        float targetYaw = yawTo(eye, point);
        double dx = point.x - eye.x;
        double dy = point.y - eye.y;
        double dz = point.z - eye.z;
        float targetPitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));

        // The selected rotation mode was Instant with 75% strength.
        float factor = (float) (Config.STRENGTH / 100.0);
        player.setYaw(player.getYaw() + MathHelper.wrapDegrees(targetYaw - player.getYaw()) * factor);
        player.setPitch(MathHelper.clamp(
                player.getPitch() + MathHelper.wrapDegrees(targetPitch - player.getPitch()) * factor,
                -90.0f, 90.0f));
    }

    private static boolean valid(LivingEntity target, ClientPlayerEntity player, Vec3d eye) {
        if (target == null || !target.isAlive() || target == player || !Config.matches(target)) return false;
        Vec3d point = target.getBoundingBox().getCenter();
        if (eye.distanceTo(point) > Config.DISTANCE) return false;
        double yawDifference = Math.abs(MathHelper.wrapDegrees(yawTo(eye, point) - player.getYaw()));
        if (yawDifference > Config.FOV / 2.0) return false;
        return player.canSee(target);
    }

    private static float yawTo(Vec3d from, Vec3d to) {
        return (float) (Math.toDegrees(Math.atan2(to.z - from.z, to.x - from.x)) - 90.0);
    }
}
