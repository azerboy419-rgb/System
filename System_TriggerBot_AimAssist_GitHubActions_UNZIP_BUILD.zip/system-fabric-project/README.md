# System TriggerBot + Aim Assist (Fabric 1.21.11)

Client-side Fabric project targeting Minecraft 1.21.11 and Java 21.

## Controls
- Press **R** to toggle both modules together.
- TriggerBot targets players only, reach 3.0 blocks, requires a sword/axe/mace/trident, waits for full attack cooldown, and only attacks in a simplified critical-hit state.
- Aim Assist targets players only, range 4.5 blocks, FOV 360°, health priority, sticky target selection, weapon condition, and 75% rotation strength.

## Important compatibility note
The original System Client sources are retained under `reference-originals/` for audit and comparison. They are **not directly compilable as a standalone Fabric mod**: they depend on the System Client's native/client-specific API, and some dependencies in the supplied source archive are stubs. The classes in `src/main/java/edge/toggle/` are a Fabric-native adaptation, not a byte-for-byte restoration of the original System Client behavior.

The critical-hit check is an approximation of Minecraft's critical-attack conditions; server-side rules, latency, and game mechanics may affect whether an attack is registered as a critical hit. This project has not been verified in a live multiplayer server.

## Build
Use Java 21, then run:

- Windows: `gradlew.bat build`
- Linux/macOS: `./gradlew build`

The remapped mod JAR is written to `build/libs/`.

See `BUILD_STATUS_RU.txt` for the exact verification status. In this environment the Gradle distribution download was blocked by a DNS/network error, so compilation has not been confirmed. With Instant rotation, the speed value is retained as requested but does not affect the 75% rotation factor.
\n\n## Smart critical TriggerBot\n\nTriggerBot waits until the attack cooldown is full and the player is descending in a possible critical-hit window. It will not attack while grounded or while rising. This is a Fabric adaptation, not the original System Client implementation. Build and in-game behavior have not been verified in this environment.\n